package com.example.prenotazione_corse_autobus.controller;

public class TripController {


}
