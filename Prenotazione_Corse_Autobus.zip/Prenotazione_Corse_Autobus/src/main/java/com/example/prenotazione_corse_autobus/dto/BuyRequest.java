package com.example.prenotazione_corse_autobus.dto;

public class BuyRequest {
    private Integer userId;  // chi compra

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
}
