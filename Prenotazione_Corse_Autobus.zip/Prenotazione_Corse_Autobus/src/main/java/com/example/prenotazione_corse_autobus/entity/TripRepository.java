package com.example.prenotazione_corse_autobus.entity;

import org.springframework.data.repository.CrudRepository;

public interface TripRepository extends CrudRepository<User, Integer> {

}
